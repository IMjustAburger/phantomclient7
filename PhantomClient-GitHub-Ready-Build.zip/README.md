# Phantom Client v1.6.0

A client-side Minecraft Fabric utility and visual-enhancement mod for **Minecraft Java Edition 1.21.11**. This source project builds into a mod JAR; the ZIP itself is not installable as a mod.

> **Verification status (read this first).** v1.6.0 was written without access to the Minecraft/Fabric/Gradle
> repositories, so it has **not been compiled and has not been tested in game**. All Java sources pass a syntax
> parse and a cross-reference check of the project's own APIs, but Minecraft-API usage is unverified until you run
> `./gradlew build`. Calls most likely to need a mapping fix are isolated in `util/Compat.java`; see "If the build fails".

## What changed in 1.6.0

* **New module framework** (`setting/`, `module/`): typed settings (toggle, slider, mode, colour, text, keybind,
  block selection) that persist automatically; a failing module is isolated and auto-disabled instead of crashing the client.
* **New ClickGUI** (`gui/`): draggable, collapsible purple/black category panels (Meteor/Anubis style), global module
  search, click to toggle, right-click or chevron to expand settings, click-to-bind keybinds (keyboard + mouse, ESC clears),
  smooth animations, HSB colour pickers, tooltips, and a bottom navigation pill: **Modules / HUD / Friends / Theme / Config**.
* **Config manager** (`config/ConfigStore`): multiple independent JSON profiles in `config/phantom/profiles/` -
  create, load, save, rename, duplicate, delete, reset. Everything (modules, settings, keybinds, colours, block
  selections, Base Finder settings, theme, panel layout) lives in the profile. Friends are global. Spawner tracking and
  chunk memory are per-world files in `config/phantom/data/`. Loading a profile now resets every setting first, so
  values no longer leak between profiles (this also fixes the old "RESET" that left sliders unchanged).
* **Fixes from the 1.5.0 review:** Flight now applies its speed slider; Entity ESP glow no longer disappears when the
  server updates entity flags; armour stands / tamed pets are no longer targeted; the save-slot overlap bug is gone
  (the old 10-slot panel is replaced by a scrollable profile list); search covers all categories.

## Modules

| Category | Modules |
|---|---|
| Combat | Aim Assist, KillAura, Auto Clicker, Auto Totem, Auto Inventory Totem, Crystal Aura, Crystal Macro, Auto City, Mace, Shield Breaker, Jump Reset |
| Player | Toggle Sneak, Auto Armor, Auto Respawn |
| Movement | Flight (speed slider), Speed, Sprint, Spider, Jesus, Auto Walk, Auto Jump, Boat Fly, Click TP, Elytra Fly, Elytra Swap, Entity Speed, Trident Boost |
| Render | Entity ESP, Storage ESP, Block ESP, Fullbright, Freecam, Hole ESP, Item ESP, Low Health Warning, Pearl Trajectory, Tracers, Trajectories |
| Base Finding | Sus Chunk Finder, Spawner Notifier, Storage Finder |
| Visuals | Custom Crosshair, Custom FOV, Block Overlay, Jump Circles |
| Misc | Auto Eat, Auto Reconnect, Auto Replenish, Block Notifier, Chat Macro, Coordinate Snapper, Fast Use, Legit Auto Tool, Weather Notifier |
| Macros | Macro 1-5 (command / chat), Panic |
| Donut | Player Detection, Netherite Finder |
| Phantom Client | Watermark, HUD (coords/FPS/CPS/ping/...), Armor HUD, Target HUD, Active Modules, Radar, Region Map, Performance, Hotkeys |

Friends list, Theme editor, HUD editor and Config manager are GUI views. All ESP modules render through walls.

### Base Finding behaviour
* **Sus Chunk Finder**: never loads chunks; remembers storage and block outlines after unload; persists across restarts;
  reconciles on chunk reload; Y level, threshold (min 4), redstone options, colour (default light purple), glow, tracers.
  Notifies once per new chunk (chat with chunk coordinates and block counts + sound).
  "Require redstone change" defaults to on, matching 1.5.0 behaviour; switch it off for storage-count-only detection.
* **Spawner Notifier**: red outline + red glow, white vertical line to world ceiling and bedrock level, on-screen coordinates.
  First sight of a new spawner: distinct sound, chat with exact coordinates, disconnect. Known spawners never disconnect
  again after reconnect and stay highlighted; a spawner observed to be broken is forgotten; a spawner at new coordinates alerts again.

## Not implemented (and why)
* **Discord Presence** - needs a native Discord IPC library that is not part of this project.
* **Xray, Nametags, Motion Blur, Hit Particles, Hand Pose, Swing Animation / Slow Swing, Time Changer, Name Protect,
  Skin Change, No Jump Delay, Boat Noclip, Entity Control** - these need Mixins into vanilla rendering/entity code.
  Mixins cannot be verified without compiling against Minecraft, so they were deliberately left out rather than shipped as
  fake modules.
* Screenshot modules that are server-specific exploits or "bypass" tools were not added; nothing here claims to evade anti-cheat.

## Notes and limits
* Combat, movement and click-teleport actions are client-side input; servers and their anti-cheat may correct or punish them.
* Crystal Aura damage is an estimate (distance only; no armour or exposure).
* Freecam swaps the camera entity and freezes your player's movement; look direction is shared with the player.
* Elytra Fly / Trident Boost rely on `isGliding()` / `isUsingRiptide()`.

## If the build fails
Fix compile errors in this order (most likely first): `util/Compat.java`, `util/RenderUtil.java` (layer code is copied from 1.5.0),
`modules/MovementModules.java`, `modules/RenderModules.java` (Freecam), `modules/CombatModules.java`, then the rest.
Send the first few compiler errors and they can be fixed quickly.

## Requirements

- Minecraft Java Edition **1.21.11**
- Fabric Loader **0.18.1 or newer**
- Fabric API **0.141.1+1.21.11**
- Java **21 or newer**
- Gradle **9.8.2**, downloaded by the included launcher on first build
- Internet access for the first build so Gradle and Maven dependencies can be downloaded

## Build the mod JAR

The project includes `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.properties`, and a small project-local bootstrap JAR. The bootstrap downloads the official Gradle 9.8.2 binary distribution, checks it against Gradle's published SHA-256 checksum, and forwards the requested command. **You do not need to install Gradle separately.** You do need a Java 21 JDK and an internet connection for the first build.

On macOS/Linux:

```bash
./gradlew build
```

Or run `./build.sh`.

On Windows:

```bat
gradlew.bat build
```

Or run `build.bat`.

The expected compiled mod is:

```text
build/libs/phantom-client-1.6.0.jar
```

Copy the JAR into the `mods` folder of a Minecraft 1.21.11 Fabric instance that also has Fabric API installed.

### Wrapper implementation note

Because this source-editing environment did not have a Gradle installation available to generate Gradle's canonical `gradle-wrapper.jar`, this project uses its included `gradle-bootstrap.jar` launcher instead. It reads the standard `gradle-wrapper.properties`, downloads only the pinned official Gradle binary, and validates the official SHA-256 before running it. The bootstrap source is included in `gradle/wrapper/src/` so it can be audited and rebuilt.

## Controls

- **Right Shift** — open or close the ClickGUI.
- **Click a module row** — select a module; click its toggle area to enable or disable it.
- **BIND button** — click, then press a keyboard key or mouse button. Press **Escape** to clear the binding.
- **Search field** — type to filter modules in the selected category.
- **Click a category** — filter the module list.
- **Click the active profile name** — cycle the default, builder, survival, and creative profiles.
- **Module Saves** — create, save, load, rename, and delete up to ten named snapshots.
- **HUD EDIT** — toggle HUD editing; drag the preview in the HUD Customizer module to move the HUD.

## Project layout

- `src/main/resources/` — Fabric metadata and language resources.
- `src/client/java/` — client initializer, ClickGUI, modules, HUD, chunk memory and configuration code.
- `gradle/wrapper/` — pinned Gradle distribution configuration and self-bootstrapping launcher.
- `build.gradle`, `settings.gradle`, and `gradle.properties` — Fabric Loom, repositories, and Minecraft build configuration.

The source archive is not itself a compiled mod. A successful build produces the installable JAR under `build/libs/`.
