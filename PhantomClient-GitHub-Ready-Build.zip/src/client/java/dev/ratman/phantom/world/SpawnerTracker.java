package dev.ratman.phantom.world;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Notifier;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Tracks mob spawners in loaded chunks. Known spawners are persisted per world/dimension so that:
 *  - a NEW spawner alerts (and may disconnect) exactly once,
 *  - reconnecting next to a known spawner never disconnects again but keeps it highlighted,
 *  - a spawner that is observed to be broken is forgotten,
 *  - a different spawner at other coordinates alerts again.
 */
public final class SpawnerTracker {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final class Params {
        public int radius = 12;
        public boolean notifyChat = true;
        public boolean notifySound = true;
        public boolean disconnect = true;
    }

    private static final Set<Long> KNOWN = new LinkedHashSet<Long>();
    private static final List<long[]> QUEUE = new ArrayList<long[]>();
    private static int queueIndex;
    private static int lastChunkX = Integer.MIN_VALUE;
    private static int lastChunkZ = Integer.MIN_VALUE;
    private static int lastRadius = -1;
    private static String worldKey = "";
    private static boolean dirty;
    private static boolean disconnectPending;
    private static String disconnectReason = "";

    private SpawnerTracker() {}

    public static List<BlockPos> known() {
        List<BlockPos> out = new ArrayList<BlockPos>();
        for (Long l : KNOWN) out.add(BlockPos.fromLong(l));
        return out;
    }

    public static void onChunkLoaded(int cx, int cz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        ensureWorld(mc);
        // Immediately look at the freshly loaded chunk on the next tick through the queue head.
        QUEUE.add(0, new long[]{cx, cz});
    }

    public static void tick(MinecraftClient mc, Params p) {
        if (mc.world == null || mc.player == null) return;
        ensureWorld(mc);

        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;
        int radius = Math.max(2, Math.min(24, p.radius));
        if (pcx != lastChunkX || pcz != lastChunkZ || radius != lastRadius || queueIndex >= QUEUE.size()) {
            rebuildQueue(pcx, pcz, radius);
        }
        int budget = 10;
        while (budget-- > 0 && queueIndex < QUEUE.size()) {
            long[] c = QUEUE.get(queueIndex++);
            scan(mc, (int) c[0], (int) c[1], p);
        }
        if (dirty) save();
        if (disconnectPending) {
            disconnectPending = false;
            String reason = disconnectReason;
            Compat.disconnect(reason);
        }
    }

    private static void rebuildQueue(int cx, int cz, int radius) {
        QUEUE.clear();
        for (int ring = 0; ring <= radius; ring++) {
            for (int x = -ring; x <= ring; x++) {
                for (int z = -ring; z <= ring; z++) {
                    if (Math.max(Math.abs(x), Math.abs(z)) != ring) continue;
                    QUEUE.add(new long[]{cx + x, cz + z});
                }
            }
        }
        queueIndex = 0;
        lastChunkX = cx;
        lastChunkZ = cz;
        lastRadius = radius;
    }

    private static void scan(MinecraftClient mc, int cx, int cz, Params p) {
        Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (chunk == null) return;

        Set<Long> found = new HashSet<Long>();
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            if (be.getCachedState().isOf(Blocks.SPAWNER)) found.add(be.getPos().asLong());
        }

        // New spawners.
        for (Long packed : found) {
            if (KNOWN.contains(packed)) continue;
            KNOWN.add(packed);
            dirty = true;
            alert(BlockPos.fromLong(packed), p);
        }

        // Broken spawners: known entries in this loaded chunk whose block is really gone.
        List<Long> gone = new ArrayList<Long>();
        for (Long packed : KNOWN) {
            BlockPos pos = BlockPos.fromLong(packed);
            if ((pos.getX() >> 4) != cx || (pos.getZ() >> 4) != cz) continue;
            if (found.contains(packed)) continue;
            BlockState state = chunk.getBlockState(pos);
            if (!state.isOf(Blocks.SPAWNER)) gone.add(packed);
        }
        if (!gone.isEmpty()) {
            KNOWN.removeAll(gone);
            dirty = true;
            for (Long packed : gone) {
                BlockPos pos = BlockPos.fromLong(packed);
                if (p.notifyChat) Notifier.chat("Spawner at " + coords(pos) + " was removed - saved detection cleared.");
            }
        }
    }

    private static void alert(BlockPos pos, Params p) {
        String where = coords(pos);
        if (p.notifyChat) Notifier.chat("Spawner detected at " + where);
        if (p.notifySound) Notifier.sound(Notifier.SOUND_SPAWNER, 1.0f, 0.8f);
        if (p.disconnect && !disconnectPending) {
            disconnectPending = true;
            disconnectReason = "Phantom: new spawner detected at " + where;
        }
    }

    public static String coords(BlockPos pos) {
        return "X " + pos.getX() + " Y " + pos.getY() + " Z " + pos.getZ();
    }

    // ------------------------------------------------------------ persistence
    private static void ensureWorld(MinecraftClient mc) {
        String key = SuspiciousChunkFinder.worldKey(mc);
        if (key.equals(worldKey)) return;
        if (!worldKey.isEmpty()) save();
        worldKey = key;
        KNOWN.clear();
        QUEUE.clear();
        queueIndex = 0;
        lastChunkX = Integer.MIN_VALUE;
        lastChunkZ = Integer.MIN_VALUE;
        dirty = false;
        disconnectPending = false;
        load();
    }

    private static Path path() {
        return ConfigStore.dataDir().resolve("spawners-" + ConfigStore.worldFileId(worldKey) + ".json");
    }

    private static void load() {
        Path path = path();
        if (!Files.exists(path)) return;
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject() || !parsed.getAsJsonObject().has("spawners")) return;
            for (JsonElement e : parsed.getAsJsonObject().getAsJsonArray("spawners")) {
                try {
                    KNOWN.add(Long.parseLong(e.getAsString()));
                } catch (RuntimeException ignored) {
                    // skip malformed entry
                }
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("[Phantom] Could not load spawner memory", e);
        }
    }

    public static void save() {
        if (worldKey.isEmpty() || !dirty) return;
        JsonObject o = new JsonObject();
        JsonArray a = new JsonArray();
        for (Long l : KNOWN) a.add(Long.toString(l));
        o.add("spawners", a);
        Path path = path();
        Path tmp = path.resolveSibling(path.getFileName().toString() + ".tmp");
        try {
            Files.createDirectories(path.getParent());
            try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                w.write(GSON.toJson(o));
            }
            Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
            dirty = false;
        } catch (IOException e) {
            LOG.error("[Phantom] Could not save spawner memory", e);
        }
    }
}
