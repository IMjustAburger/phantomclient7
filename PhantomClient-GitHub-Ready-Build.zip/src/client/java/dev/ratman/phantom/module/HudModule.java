package dev.ratman.phantom.module;

import dev.ratman.phantom.setting.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * A module that draws a movable element on the HUD. Position is stored in two hidden settings so it
 * persists with the profile. {@link #draw} must set {@link #boxW}/{@link #boxH} so the HUD editor can
 * hit-test and drag the element.
 */
public abstract class HudModule extends Module {
    protected final Setting.Num posX;
    protected final Setting.Num posY;
    public int boxW = 80;
    public int boxH = 20;

    protected HudModule(String id, String name, String description, int defX, int defY) {
        super(id, name, ModuleCategory.CLIENT, description);
        posX = add(new Setting.Num("x", "X", defX, 0, 4000, 1, ""));
        posY = add(new Setting.Num("y", "Y", defY, 0, 4000, 1, ""));
        posX.visibleWhen(() -> false);
        posY.visibleWhen(() -> false);
    }

    public int x() { return posX.i(); }

    public int y() { return posY.i(); }

    public void moveTo(int x, int y) {
        posX.set((double) x);
        posY.set((double) y);
    }

    /** Draw the element at its stored position. {@code editing} is true inside the HUD editor. */
    public abstract void draw(DrawContext context, float tickDelta, boolean editing);

    @Override
    public void onHud(DrawContext context, float tickDelta) {
        draw(context, tickDelta, false);
    }
}
