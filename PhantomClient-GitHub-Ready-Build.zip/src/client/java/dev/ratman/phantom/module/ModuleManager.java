package dev.ratman.phantom.module;

import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.modules.BaseModules;
import dev.ratman.phantom.modules.ClientModules;
import dev.ratman.phantom.modules.CombatModules;
import dev.ratman.phantom.modules.DonutModules;
import dev.ratman.phantom.modules.MacroModules;
import dev.ratman.phantom.modules.MiscModules;
import dev.ratman.phantom.modules.MovementModules;
import dev.ratman.phantom.modules.PlayerModules;
import dev.ratman.phantom.modules.RenderModules;
import dev.ratman.phantom.modules.VisualModules;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.Targets;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Registry and dispatcher for all modules. */
public final class ModuleManager {
    private static final Logger LOG = LogUtils.getLogger();
    private static final List<Module> MODULES = new ArrayList<Module>();
    private static final Map<String, Module> BY_ID = new LinkedHashMap<String, Module>();
    private static final Set<String> HELD_KEYS = new HashSet<String>();
    private static boolean initialised;
    private static ClientWorld lastWorld;
    private static final int MAX_CONSECUTIVE_ERRORS = 5;

    private ModuleManager() {}

    public static void init() {
        if (initialised) return;
        initialised = true;
        CombatModules.register();
        PlayerModules.register();
        MovementModules.register();
        RenderModules.register();
        BaseModules.register();
        VisualModules.register();
        MiscModules.register();
        MacroModules.register();
        DonutModules.register();
        ClientModules.register();
    }

    public static void register(Module module) {
        if (BY_ID.containsKey(module.id)) throw new IllegalStateException("Duplicate module id " + module.id);
        MODULES.add(module);
        BY_ID.put(module.id, module);
    }

    public static List<Module> all() { return MODULES; }

    public static Module byId(String id) { return BY_ID.get(id); }

    public static boolean enabled(String id) {
        Module m = BY_ID.get(id);
        return m != null && m.enabled();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static List<Module> inCategory(ModuleCategory category) {
        List<Module> out = new ArrayList<Module>();
        for (Module m : MODULES) if (m.category == category) out.add(m);
        return out;
    }

    public static void panic() {
        for (Module m : new ArrayList<Module>(MODULES)) {
            if (!m.alwaysOn && m.enabled()) m.setEnabled(false);
        }
    }

    // ----------------------------------------------------------------- dispatch
    public static void tick(MinecraftClient mc) {
        ConfigStore.tick();
        if (mc.player == null || mc.world == null) {
            if (lastWorld != null) {
                lastWorld = null;
                resetWorldState();
            }
            for (int i = 0; i < MODULES.size(); i++) {
                Module m = MODULES.get(i);
                if (!m.enabled()) continue;
                try {
                    m.onIdle();
                } catch (RuntimeException e) {
                    handleError(m, "idle", e);
                }
            }
            return;
        }
        if (mc.world != lastWorld) {
            if (lastWorld != null) resetWorldState();
            lastWorld = mc.world;
        }
        Targets.trackMotion();
        if (mc.currentScreen == null) pollKeys(mc);
        for (int i = 0; i < MODULES.size(); i++) {
            Module m = MODULES.get(i);
            if (!m.enabled()) continue;
            try {
                m.onTick();
                m.consecutiveErrors = 0;
            } catch (RuntimeException e) {
                handleError(m, "tick", e);
            }
        }
    }

    public static void preTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        for (int i = 0; i < MODULES.size(); i++) {
            Module m = MODULES.get(i);
            if (!m.enabled()) continue;
            try {
                m.onPreTick();
            } catch (RuntimeException e) {
                handleError(m, "pretick", e);
            }
        }
    }

    public static void frame(float dt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (int i = 0; i < MODULES.size(); i++) {
            Module m = MODULES.get(i);
            if (!m.enabled()) continue;
            try {
                m.onFrame(dt);
            } catch (RuntimeException e) {
                handleError(m, "frame", e);
            }
        }
    }

    public static void renderWorld(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        float td = Compat.tickDelta();
        for (int i = 0; i < MODULES.size(); i++) {
            Module m = MODULES.get(i);
            if (!m.enabled()) continue;
            try {
                m.onRender3D(context, td);
            } catch (RuntimeException e) {
                handleError(m, "render", e);
            }
        }
    }

    public static void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        for (int i = 0; i < MODULES.size(); i++) {
            Module m = MODULES.get(i);
            if (!m.enabled()) continue;
            try {
                m.onHud(context, tickDelta);
            } catch (RuntimeException e) {
                handleError(m, "hud", e);
            }
        }
    }

    private static void resetWorldState() {
        for (Module m : MODULES) {
            try {
                m.onWorldReset();
            } catch (RuntimeException e) {
                LOG.error("[Phantom] {} failed on world reset", m.name, e);
            }
        }
    }

    private static void handleError(Module m, String phase, RuntimeException e) {
        m.consecutiveErrors++;
        LOG.error("[Phantom] {} threw during {}", m.name, phase, e);
        if (m.consecutiveErrors >= MAX_CONSECUTIVE_ERRORS && !m.alwaysOn) {
            m.consecutiveErrors = 0;
            m.setEnabled(false);
            Notifier.chat(m.name + " was disabled after repeated errors. Details are in the game log.");
        }
    }

    // --------------------------------------------------------------- keybinds
    private static void pollKeys(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            int key = m.keyCode();
            if (key == -1) continue;
            boolean down;
            if (key <= -100) down = GLFW.glfwGetMouseButton(window, -100 - key) == GLFW.GLFW_PRESS;
            else down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
            if (down) {
                if (HELD_KEYS.add(m.id) && !m.alwaysOn) m.toggle();
            } else {
                HELD_KEYS.remove(m.id);
            }
        }
    }

    public static String keyName(int key) {
        if (key == -1) return "NONE";
        if (key <= -100) {
            int b = -100 - key;
            if (b == 0) return "LMB";
            if (b == 1) return "RMB";
            if (b == 2) return "MMB";
            return "MOUSE" + (b + 1);
        }
        switch (key) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_BACKSPACE: return "BKSP";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            case GLFW.GLFW_KEY_INSERT: return "INS";
            case GLFW.GLFW_KEY_DELETE: return "DEL";
            case GLFW.GLFW_KEY_HOME: return "HOME";
            case GLFW.GLFW_KEY_END: return "END";
            case GLFW.GLFW_KEY_PAGE_UP: return "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PGDN";
            case GLFW.GLFW_KEY_GRAVE_ACCENT: return "`";
            default: break;
        }
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        String name = GLFW.glfwGetKeyName(key, 0);
        if (name != null) return name.toUpperCase(java.util.Locale.ROOT);
        return "K" + key;
    }
}
