package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Inv;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** Player category. */
public final class PlayerModules {
    private PlayerModules() {}

    public static void register() {
        ModuleManager.register(new ToggleSneak());
        ModuleManager.register(new AutoArmor());
        ModuleManager.register(new AutoRespawn());
    }

    // ================================================================== Toggle Sneak
    static final class ToggleSneak extends Module {
        private boolean forced;

        ToggleSneak() {
            super("toggle_sneak", "Toggle Sneak", ModuleCategory.PLAYER, "Holds the vanilla sneak key while enabled.");
        }

        @Override public void onTick() {
            if (mc.currentScreen == null) {
                mc.options.sneakKey.setPressed(true);
                forced = true;
            }
        }

        @Override public void onDisable() {
            if (forced) KeyBinding.updatePressedStates();
            forced = false;
        }
    }

    // ================================================================== Auto Armor
    static final class AutoArmor extends Module {
        final Setting.Num delay = num("delay", "Delay", 4.0, 0.0, 20.0, 1.0, " ticks");
        private int wait;

        AutoArmor() {
            super("auto_armor", "Auto Armor", ModuleCategory.PLAYER,
                    "Equips better armour from your inventory (netherite > diamond > iron > chain > gold > leather).");
        }

        private static int rank(ItemStack s) {
            if (s.isEmpty()) return -1;
            String path = Registries.ITEM.getId(s.getItem()).getPath();
            if (path.startsWith("netherite_")) return 6;
            if (path.startsWith("diamond_")) return 5;
            if (path.startsWith("iron_")) return 4;
            if (path.startsWith("chainmail_")) return 3;
            if (path.startsWith("golden_")) return 2;
            if (path.startsWith("leather_")) return 1;
            return 0;
        }

        private static int pieceOf(ItemStack s) {
            if (s.isEmpty()) return -1;
            String path = Registries.ITEM.getId(s.getItem()).getPath();
            if (path.endsWith("_helmet")) return 0;
            if (path.endsWith("_chestplate")) return 1;
            if (path.endsWith("_leggings")) return 2;
            if (path.endsWith("_boots")) return 3;
            return -1;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!Inv.canClick()) return;
            if (wait > 0) {
                wait--;
                return;
            }
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int piece = 0; piece < 4; piece++) {
                int worn = rank(p.getEquippedStack(slots[piece]));
                int bestIdx = -1;
                int bestRank = worn;
                for (int i = 0; i < 36; i++) {
                    ItemStack s = p.getInventory().getStack(i);
                    if (pieceOf(s) != piece) continue;
                    int r = rank(s);
                    if (r > bestRank) {
                        bestRank = r;
                        bestIdx = i;
                    }
                }
                if (bestIdx >= 0) {
                    int armorSlotId = 5 + piece;
                    Inv.click(Inv.slotId(bestIdx), 0, SlotActionType.PICKUP);
                    Inv.click(armorSlotId, 0, SlotActionType.PICKUP);
                    Inv.click(Inv.slotId(bestIdx), 0, SlotActionType.PICKUP);
                    wait = delay.i() + 1;
                    return;
                }
            }
        }
    }

    // ================================================================== Auto Respawn
    static final class AutoRespawn extends Module {
        AutoRespawn() {
            super("auto_respawn", "Auto Respawn", ModuleCategory.PLAYER, "Respawns instantly when you die.");
        }

        @Override public void onTick() {
            if (mc.currentScreen instanceof DeathScreen || mc.player.isDead()) {
                mc.player.requestRespawn();
                mc.setScreen(null);
            }
        }
    }
}
