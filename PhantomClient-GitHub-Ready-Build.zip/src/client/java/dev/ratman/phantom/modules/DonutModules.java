package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.RenderUtil;
import dev.ratman.phantom.world.BlockScanner;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Donut category: helpers aimed at long-running survival / base-hunting servers. */
public final class DonutModules {
    private DonutModules() {}

    public static void register() {
        ModuleManager.register(new PlayerDetection());
        ModuleManager.register(new NetheriteFinder());
    }

    // ================================================================== Player Detection
    static final class PlayerDetection extends Module {
        final Setting.Num range = num("range", "Detection range", 128.0, 16.0, 512.0, 8.0, " blocks");
        final Setting.Bool ignoreFriends = bool("friends", "Ignore friends", true);
        final Setting.Bool chat = bool("chat", "Chat message", true);
        final Setting.Bool sound = bool("sound", "Sound", true);
        final Setting.Bool disconnect = bool("disconnect", "Disconnect when detected", false);
        private final Map<Integer, Long> inRange = new HashMap<Integer, Long>();

        PlayerDetection() {
            super("player_detection", "Player Detection", ModuleCategory.DONUT, "Alerts when another player comes within range.");
        }

        @Override public void onWorldReset() { inRange.clear(); }

        @Override public void onTick() {
            List<AbstractClientPlayerEntity> players = mc.world.getPlayers();
            double r2 = range.d() * range.d();
            long now = System.currentTimeMillis();
            Map<Integer, Boolean> present = new HashMap<Integer, Boolean>();
            for (AbstractClientPlayerEntity p : players) {
                if (p == mc.player || mc.player.squaredDistanceTo(p) > r2) continue;
                String name = p.getName().getString();
                if (ignoreFriends.on() && Friends.is(name)) continue;
                present.put(p.getId(), true);
                if (!inRange.containsKey(p.getId())) {
                    inRange.put(p.getId(), now);
                    if (chat.on()) {
                        Notifier.chat(name + " is within " + Math.round(Math.sqrt(mc.player.squaredDistanceTo(p))) + " blocks at X "
                                + p.getBlockX() + " Y " + p.getBlockY() + " Z " + p.getBlockZ());
                    }
                    if (sound.on()) Notifier.sound(Notifier.SOUND_WARN, 0.8f, 1.2f);
                    if (disconnect.on()) Compat.disconnect("Phantom: player detected (" + name + ")");
                }
            }
            Iterator<Integer> it = inRange.keySet().iterator();
            while (it.hasNext()) if (!present.containsKey(it.next())) it.remove();
        }
    }

    // ================================================================== Netherite Finder
    static final class NetheriteFinder extends Module {
        final Setting.Col debrisColor = color("debris", "Ancient debris", 0xFFFF9F43);
        final Setting.Col blockColor = color("block", "Netherite block", 0xFFE9D5FF);
        final Setting.Num radius = num("radius", "Scan radius", 5.0, 1.0, 10.0, 1.0, " chunks");
        final Setting.Num minY = num("miny", "Min Y", 0.0, -64.0, 320.0, 1.0);
        final Setting.Num maxY = num("maxy", "Max Y", 128.0, -64.0, 320.0, 1.0);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        private final BlockScanner scanner = new BlockScanner();

        NetheriteFinder() {
            super("netherite_finder", "Netherite Finder", ModuleCategory.DONUT,
                    "Highlights ancient debris and netherite blocks through walls.");
        }

        @Override public void onEnable() { scanner.invalidate(); }

        @Override public void onWorldReset() { scanner.invalidate(); }

        @Override public void onTick() {
            scanner.tick(mc, id -> id.equals("ancient_debris") || id.equals("netherite_block"), radius.i(),
                    ClientModules.scansPerTick(), ClientModules.rescanMs(), minY.i(), maxY.i());
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            int drawn = 0;
            for (BlockScanner.Hit h : scanner.hits()) {
                if (drawn++ > 1500) break;
                int c = h.id.equals("ancient_debris") ? debrisColor.argb() : blockColor.argb();
                Box b = new Box(h.pos);
                pass.box(b, c, 0, 0f);
                if (glow.on()) pass.glow(b, c, 2, 1.0f);
                if (tracers.on()) pass.tracer(Vec3d.ofCenter(h.pos), c);
            }
        }
    }
}
