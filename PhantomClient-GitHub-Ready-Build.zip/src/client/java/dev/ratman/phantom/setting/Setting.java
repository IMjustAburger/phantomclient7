package dev.ratman.phantom.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Base type for every configurable value. Each concrete setting knows how to persist itself to
 * JSON so profiles can store module settings generically.
 */
public abstract class Setting<T> {
    public final String key;
    public final String label;
    public String description = "";
    protected T value;
    protected final T def;
    private BooleanSupplier visible = () -> true;

    protected Setting(String key, String label, T def) {
        this.key = key;
        this.label = label;
        this.def = def;
        this.value = def;
    }

    public T get() { return value; }

    public void set(T v) { this.value = sanitize(v); }

    protected T sanitize(T v) { return v; }

    public void reset() { this.value = def; }

    public boolean isDefault() { return value == null ? def == null : value.equals(def); }

    public Setting<T> visibleWhen(BooleanSupplier supplier) {
        this.visible = supplier;
        return this;
    }

    public Setting<T> describe(String text) {
        this.description = text;
        return this;
    }

    public boolean visible() { return visible.getAsBoolean(); }

    public abstract JsonElement save();

    public abstract void load(JsonElement element);

    // ---------------------------------------------------------------- Bool
    public static final class Bool extends Setting<Boolean> {
        public Bool(String key, String label, boolean def) { super(key, label, def); }

        public boolean on() { return value; }

        public void toggle() { value = !value; }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) value = e.getAsBoolean();
        }
    }

    // ---------------------------------------------------------------- Num
    public static final class Num extends Setting<Double> {
        public final double min;
        public final double max;
        public final double step;
        public final String suffix;

        public Num(String key, String label, double def, double min, double max, double step, String suffix) {
            super(key, label, def);
            this.min = min;
            this.max = max;
            this.step = step;
            this.suffix = suffix == null ? "" : suffix;
            this.value = clampStep(def);
        }

        private double clampStep(double v) {
            if (Double.isNaN(v) || Double.isInfinite(v)) return def;
            double c = Math.max(min, Math.min(max, v));
            if (step > 0) {
                c = min + Math.round((c - min) / step) * step;
                c = Math.max(min, Math.min(max, c));
            }
            return c;
        }

        @Override protected Double sanitize(Double v) { return v == null ? def : clampStep(v); }

        public double d() { return value; }

        public float f() { return value.floatValue(); }

        public int i() { return (int) Math.round(value); }

        public double ratio() { return max <= min ? 0 : (value - min) / (max - min); }

        public void setRatio(double r) { set(min + Math.max(0, Math.min(1, r)) * (max - min)); }

        public String display() {
            if (step >= 1 && Math.abs(step - Math.rint(step)) < 1e-9) return Math.round(value) + suffix;
            double shown = Math.abs(value - Math.rint(value)) < 1e-9 ? Math.rint(value) : value;
            if (shown == Math.rint(shown)) return Long.toString(Math.round(shown)) + suffix;
            return String.format(java.util.Locale.ROOT, step < 0.1 ? "%.2f" : "%.1f", shown) + suffix;
        }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) set(e.getAsDouble());
        }
    }

    // ---------------------------------------------------------------- Mode
    public static final class Mode extends Setting<String> {
        public final String[] modes;

        public Mode(String key, String label, String def, String... modes) {
            super(key, label, def);
            this.modes = modes;
        }

        public int index() {
            for (int i = 0; i < modes.length; i++) if (modes[i].equals(value)) return i;
            return 0;
        }

        public void cycle(int dir) {
            int n = modes.length;
            value = modes[Math.floorMod(index() + dir, n)];
        }

        public boolean is(String mode) { return value.equals(mode); }

        @Override protected String sanitize(String v) {
            for (String m : modes) if (m.equals(v)) return v;
            return def;
        }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive()) set(e.getAsString());
        }
    }

    // ---------------------------------------------------------------- Col
    public static final class Col extends Setting<Integer> {
        public final boolean allowAlpha;

        public Col(String key, String label, int argb, boolean allowAlpha) {
            super(key, label, argb);
            this.allowAlpha = allowAlpha;
            this.value = sanitize(argb);
        }

        @Override protected Integer sanitize(Integer v) {
            int c = v == null ? def : v;
            return allowAlpha ? c : (c | 0xFF000000);
        }

        public int argb() { return value; }

        public int withAlpha(float alpha) {
            int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
            return (value & 0xFFFFFF) | (a << 24);
        }

        @Override public JsonElement save() { return new JsonPrimitive(String.format("#%08X", value)); }

        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonPrimitive()) return;
            try {
                String s = e.getAsString().trim();
                if (s.startsWith("#")) s = s.substring(1);
                set((int) Long.parseLong(s, 16));
            } catch (NumberFormatException ignored) {
                // keep previous value
            }
        }
    }

    // ---------------------------------------------------------------- Text
    public static final class Text extends Setting<String> {
        public final int maxLength;

        public Text(String key, String label, String def, int maxLength) {
            super(key, label, def);
            this.maxLength = maxLength;
        }

        @Override protected String sanitize(String v) {
            if (v == null) return def;
            return v.length() > maxLength ? v.substring(0, maxLength) : v;
        }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive()) set(e.getAsString());
        }
    }

    // ---------------------------------------------------------------- Key
    public static final class KeyBind extends Setting<Integer> {
        public KeyBind(String key, String label, int def) { super(key, label, def); }

        @Override public JsonElement save() { return new JsonPrimitive(value); }

        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) value = e.getAsInt();
        }
    }

    // ---------------------------------------------------------------- Blocks
    /**
     * A selection of block identifiers (path only for minecraft:, otherwise full id) each with an
     * individual colour. Used by Block ESP, Storage ESP and Block Notifier.
     */
    public static final class Blocks extends Setting<LinkedHashMap<String, Integer>> {
        public int defaultColor;
        /** When non-null the picker only offers these identifiers. */
        public final List<String> candidates;
        public final boolean emptyMeansAll;

        public Blocks(String key, String label, int defaultColor, List<String> candidates, boolean emptyMeansAll) {
            super(key, label, new LinkedHashMap<String, Integer>());
            this.defaultColor = defaultColor;
            this.candidates = candidates;
            this.emptyMeansAll = emptyMeansAll;
        }

        public Map<String, Integer> map() { return value; }

        public boolean contains(String id) { return value.containsKey(id); }

        public void toggle(String id) {
            if (value.containsKey(id)) value.remove(id);
            else value.put(id, defaultColor);
        }

        public void setColor(String id, int argb) { if (value.containsKey(id)) value.put(id, argb); }

        public int colorOf(String id) {
            Integer c = value.get(id);
            return c == null ? defaultColor : c;
        }

        public boolean accepts(String id) {
            return value.isEmpty() ? emptyMeansAll : value.containsKey(id);
        }

        @Override public void reset() { value = new LinkedHashMap<String, Integer>(); }

        @Override public boolean isDefault() { return value.isEmpty(); }

        @Override public JsonElement save() {
            JsonObject o = new JsonObject();
            o.addProperty("default", String.format("#%08X", defaultColor));
            JsonObject blocks = new JsonObject();
            for (Map.Entry<String, Integer> e : value.entrySet()) {
                blocks.addProperty(e.getKey(), String.format("#%08X", e.getValue()));
            }
            o.add("blocks", blocks);
            return o;
        }

        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonObject()) return;
            JsonObject o = e.getAsJsonObject();
            try {
                if (o.has("default")) defaultColor = (int) Long.parseLong(o.get("default").getAsString().replace("#", ""), 16);
            } catch (NumberFormatException ignored) {
                // keep default colour
            }
            LinkedHashMap<String, Integer> loaded = new LinkedHashMap<String, Integer>();
            if (o.has("blocks") && o.get("blocks").isJsonObject()) {
                for (Map.Entry<String, JsonElement> entry : o.getAsJsonObject("blocks").entrySet()) {
                    try {
                        loaded.put(entry.getKey(), (int) Long.parseLong(entry.getValue().getAsString().replace("#", ""), 16));
                    } catch (RuntimeException ignored) {
                        loaded.put(entry.getKey(), defaultColor);
                    }
                }
            }
            value = loaded;
        }

        public List<String> ids() { return new ArrayList<String>(value.keySet()); }
    }
}
