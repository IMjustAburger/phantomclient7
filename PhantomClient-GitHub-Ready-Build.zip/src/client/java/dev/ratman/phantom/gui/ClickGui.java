package dev.ratman.phantom.gui;

import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.module.HudModule;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Theme;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Phantom ClickGUI: floating, draggable category panels (Modules view) plus HUD editor, Friends,
 * Theme and Config (profile manager) views, with a bottom navigation pill.
 */
public final class ClickGui extends GuiBase {
    private enum View {
        MODULES("Modules"), HUD("HUD"), FRIENDS("Friends"), THEME("Theme"), CONFIG("Config");

        final String label;

        View(String label) { this.label = label; }
    }

    private static final int PANEL_W = 150;
    private static final int HEADER_H = 22;
    private static final int ROW_H = 17;
    private static final int PANEL_MAX_H = 230;

    private static View lastView = View.MODULES;
    private View view = lastView;

    private static final class Panel {
        final String id;
        final ModuleCategory cat;
        float scroll;
        int rx, ry, rw, rh;

        Panel(String id, ModuleCategory cat) {
            this.id = id;
            this.cat = cat;
        }
    }

    private final List<Panel> panels = new ArrayList<Panel>();
    private final TextBox search = new TextBox(32);
    private final Set<Module> expanded = new HashSet<Module>();
    private final Set<Object> openColors = new HashSet<Object>();
    private Module bindModule;
    private Setting.KeyBind bindSetting;
    private Module hoverModule;
    private float openAnim;
    private float navX = -1f;
    private final long openedAt = System.currentTimeMillis();

    // Friends view state
    private final TextBox friendInput = new TextBox(16);
    private int friendScroll;
    private String friendStatus = "";

    // Config view state
    private final TextBox configName = new TextBox(24);
    private String selectedProfile = ConfigStore.active();
    private String cfgStatus = "";
    private boolean cfgGood = true;
    private long cfgStatusUntil;
    private String confirmDelete = "";
    private long confirmUntil;
    private int cfgScroll;

    // Theme view state
    private boolean themePickerOpen;

    public ClickGui() {
        super("Phantom Client");
        for (ModuleCategory cat : ModuleCategory.values()) panels.add(new Panel(cat.name(), cat));
        panels.add(new Panel("search", null));
        search.placeholder = "Search modules...";
        friendInput.placeholder = "Player name";
        configName.placeholder = "Config name";
    }

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void init() {
        int perRow = Math.max(1, (this.width - 16) / (PANEL_W + 8));
        int index = 0;
        for (Panel p : panels) {
            GuiState.PanelState st = GuiState.panel(p.id);
            if (st.x == Integer.MIN_VALUE) {
                if (p.cat == null) {
                    st.x = (this.width - PANEL_W) / 2;
                    st.y = 6;
                } else {
                    int col = index % perRow;
                    int row = index / perRow;
                    st.x = 8 + col * (PANEL_W + 8);
                    st.y = 52 + row * (PANEL_MAX_H + 34);
                    index++;
                }
            }
        }
    }

    @Override
    public void removed() { ConfigStore.flush(); }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        // drawn in render()
    }

    private void setView(View v) {
        view = v;
        lastView = v;
        focused = null;
        bindModule = null;
        bindSetting = null;
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        beginFrame(mx, my);
        openAnim = Draw.approach(openAnim, 1f, 1f - (float) Math.exp(-dt * 14f * Theme.animSpeed));
        hoverModule = null;
        c.fillGradient(0, 0, this.width, this.height, Draw.alpha(0xFF05030A, 0.78f * openAnim), Draw.alpha(0xFF14082A, 0.9f * openAnim));

        if (view == View.MODULES) renderModulesView(c);
        else if (view == View.HUD) renderHudView(c);
        else if (view == View.FRIENDS) renderFriendsView(c);
        else if (view == View.THEME) renderThemeView(c);
        else renderConfigView(c);

        renderNav(c);
        if (view == View.MODULES && hoverModule != null) renderTooltip(c, hoverModule);
    }

    // ------------------------------------------------------------------ nav
    private void renderNav(DrawContext c) {
        View[] views = View.values();
        int tabW = 62;
        int total = views.length * tabW + 8;
        int x = (this.width - total) / 2;
        int y = this.height - 28;
        Draw.rrectBorder(c, x, y, total, 20, 9, Draw.alpha(0xFF0B0713, 0.96f), Theme.BORDER);
        int idx = view.ordinal();
        float target = x + 4 + idx * tabW;
        navX = navX < 0 ? target : navX + (target - navX) * (1f - (float) Math.exp(-dt * 18f * Theme.animSpeed));
        Draw.rrect(c, Math.round(navX), y + 3, tabW, 14, 7, Theme.accent());
        for (int i = 0; i < views.length; i++) {
            final View v = views[i];
            int tx = x + 4 + i * tabW;
            Draw.textCentered(c, this.textRenderer, v.label, tx + tabW / 2, y + 6, i == idx ? 0xFF0B0713 : Theme.MUTED);
            hit(tx, y, tabW, 20, new Runnable() {
                @Override public void run() { setView(v); }
            }, null, null);
        }
    }

    // ------------------------------------------------------------------ modules view
    private void renderModulesView(DrawContext c) {
        int slide = Math.round((1f - openAnim) * -16f);
        for (Panel p : new ArrayList<Panel>(panels)) renderPanel(c, p, slide);
    }

    private List<Module> visibleModules(Panel p) {
        String q = search.text.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<Module>();
        for (Module m : ModuleManager.inCategory(p.cat)) {
            if (q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q) || m.id.contains(q)) out.add(m);
        }
        return out;
    }

    private void bringToFront(Panel p) {
        panels.remove(p);
        panels.add(p);
    }

    private void renderPanel(DrawContext c, final Panel p, int slide) {
        final GuiState.PanelState st = GuiState.panel(p.id);
        if (st.x == Integer.MIN_VALUE) return;
        st.x = Math.max(0, Math.min(this.width - PANEL_W, st.x));
        st.y = Math.max(0, Math.min(this.height - HEADER_H - 30, st.y));
        final int x = st.x;
        final int y = st.y + slide;

        if (p.cat == null) {
            renderSearchPanel(c, p, st, x, y);
            return;
        }
        List<Module> mods = visibleModules(p);
        boolean searching = !search.text.trim().isEmpty();
        if (mods.isEmpty()) return;

        float open = anim(p.id + "#open", (st.collapsed && !searching) ? 0f : 1f);
        int content = 0;
        int[] shown = new int[mods.size()];
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            float ea = anim(m.id + "#exp", expanded.contains(m) ? 1f : 0f);
            shown[i] = Math.round(layoutSettings(null, m, 0, 0, PANEL_W - 14, false) * ea);
            content += ROW_H + shown[i];
        }
        int fullBody = content + 6;
        int bodyH = Math.min(PANEL_MAX_H, fullBody);
        int visible = Math.round(bodyH * open);
        int maxScroll = Math.max(0, fullBody - PANEL_MAX_H);
        p.scroll = Math.max(0, Math.min(maxScroll, p.scroll));
        p.rx = x;
        p.ry = y;
        p.rw = PANEL_W;
        p.rh = HEADER_H + visible;

        card(c, x, y, PANEL_W, HEADER_H + visible);
        c.fillGradient(x + 1, y + 1, x + PANEL_W - 1, y + HEADER_H, Draw.alpha(Theme.accent(), 0.30f), Draw.alpha(Theme.accent(), 0.04f));
        Draw.rrect(c, x + 8, y + 7, 7, 7, 3, Theme.accent());
        Draw.text(c, this.textRenderer, p.cat.label(), x + 21, y + 7, Theme.TEXT);
        int enabledCount = 0;
        for (Module m : ModuleManager.inCategory(p.cat)) if (m.enabled() && !m.alwaysOn) enabledCount++;
        if (enabledCount > 0) Draw.textRight(c, this.textRenderer, String.valueOf(enabledCount), x + PANEL_W - 26, y + 7, Theme.MUTED);
        Draw.chevron(c, x + PANEL_W - 17, y + 9, Theme.MUTED, open > 0.5f);

        // consume everything inside the panel so clicks do not fall through to panels below
        hit(x, y, PANEL_W, HEADER_H + visible, new Runnable() {
            @Override public void run() { bringToFront(p); }
        }, null, null);
        final double[] grab = new double[]{Double.NaN, 0};
        hit(x, y, PANEL_W - 24, HEADER_H, new Runnable() {
            @Override public void run() {
                bringToFront(p);
                grab[0] = Double.NaN;
            }
        }, null, new Drag() {
            @Override public void to(double mxx, double myy) {
                if (Double.isNaN(grab[0])) {
                    grab[0] = mxx - st.x;
                    grab[1] = myy - st.y;
                }
                st.x = (int) Math.round(mxx - grab[0]);
                st.y = (int) Math.round(myy - grab[1]);
                ConfigStore.markDirty();
            }
        });
        hit(x + PANEL_W - 24, y, 24, HEADER_H, new Runnable() {
            @Override public void run() {
                st.collapsed = !st.collapsed;
                ConfigStore.markDirty();
            }
        }, null, null);

        if (visible > 0 && pushClip(c, x + 1, y + HEADER_H, PANEL_W - 2, visible)) {
            int yy = y + HEADER_H + 2 - Math.round(p.scroll);
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                drawModuleRow(c, m, x + 3, yy, PANEL_W - 6);
                if (shown[i] > 0) {
                    int sy = yy + ROW_H - 1;
                    if (pushClip(c, x + 3, sy, PANEL_W - 6, shown[i] + 1)) {
                        c.fill(x + 3, sy, x + PANEL_W - 3, sy + shown[i] + 1, 0xFF0D0919);
                        layoutSettings(c, m, x + 7, sy + 1, PANEL_W - 14, true);
                        popClip(c);
                    }
                }
                yy += ROW_H + shown[i];
            }
            popClip(c);
        }
        if (maxScroll > 0 && visible > 8) {
            int trackH = visible - 6;
            int thumbH = Math.max(12, Math.round(trackH * (PANEL_MAX_H / (float) fullBody)));
            int thumbY = y + HEADER_H + 3 + Math.round((trackH - thumbH) * (p.scroll / maxScroll));
            c.fill(x + PANEL_W - 3, thumbY, x + PANEL_W - 1, thumbY + thumbH, Draw.alpha(Theme.accent(), 0.6f));
        }
    }

    private void renderSearchPanel(DrawContext c, final Panel p, final GuiState.PanelState st, int x, int y) {
        int h = HEADER_H + 26;
        p.rx = x;
        p.ry = y;
        p.rw = PANEL_W;
        p.rh = h;
        card(c, x, y, PANEL_W, h);
        c.fillGradient(x + 1, y + 1, x + PANEL_W - 1, y + HEADER_H, Draw.alpha(Theme.accent(), 0.30f), Draw.alpha(Theme.accent(), 0.04f));
        Draw.rrect(c, x + 8, y + 7, 7, 7, 3, Theme.accent());
        Draw.text(c, this.textRenderer, "Search", x + 21, y + 7, Theme.TEXT);
        hit(x, y, PANEL_W, h, new Runnable() {
            @Override public void run() { bringToFront(p); }
        }, null, null);
        final double[] grab = new double[]{Double.NaN, 0};
        hit(x, y, PANEL_W, HEADER_H, new Runnable() {
            @Override public void run() { grab[0] = Double.NaN; }
        }, null, new Drag() {
            @Override public void to(double mxx, double myy) {
                if (Double.isNaN(grab[0])) {
                    grab[0] = mxx - st.x;
                    grab[1] = myy - st.y;
                }
                st.x = (int) Math.round(mxx - grab[0]);
                st.y = (int) Math.round(myy - grab[1]);
                ConfigStore.markDirty();
            }
        });
        textBox(c, x + 6, y + HEADER_H + 4, PANEL_W - 12, 14, search);
    }

    private void drawModuleRow(DrawContext c, final Module m, int x, int y, int w) {
        boolean hov = hovered(x, y, w, ROW_H - 1);
        if (hov) hoverModule = m;
        float on = anim(m.id + "#on", m.enabled() && !m.alwaysOn ? 1f : 0f);
        float hv = animFromZero(m.id + "#hov", hov ? 1f : 0f);
        int base = Draw.lerp(Theme.ROW, Theme.ROW_HOVER, hv);
        int active = Draw.lerp(Draw.mul(Theme.accent(), 0.50f), Theme.accent(), hv * 0.35f);
        int bg = Draw.lerp(base, active, on);
        Draw.rrect(c, x, y, w, ROW_H - 1, Math.max(1, Theme.cornerRadius - 1), bg);
        if (on > 0.01f) c.fill(x, y + 3, x + 2, y + ROW_H - 4, Draw.alpha(0xFFFFFFFF, 0.65f * on));
        int tc = Draw.lerp(Draw.lerp(Theme.MUTED, Theme.TEXT, hv), 0xFFFFFFFF, on);
        Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, m.name, w - 34), x + 8, y + 4, tc);
        boolean open = expanded.contains(m);
        if (m.keyCode() != -1) {
            String k = ModuleManager.keyName(m.keyCode());
            Draw.textRight(c, this.textRenderer, Draw.fit(this.textRenderer, k, 30), x + w - 14, y + 4, Draw.lerp(Theme.DIM, 0xFFE9D5FF, on));
        }
        Draw.chevron(c, x + w - 11, y + 5, Draw.lerp(Theme.DIM, Theme.TEXT, Math.max(hv, on)), open);
        hit(x, y, w, ROW_H - 1, new Runnable() {
            @Override public void run() {
                if (!m.alwaysOn) m.toggle();
                else toggleExpand(m);
            }
        }, new Runnable() {
            @Override public void run() { toggleExpand(m); }
        }, null);
        // chevron area always expands
        hit(x + w - 18, y, 18, ROW_H - 1, new Runnable() {
            @Override public void run() { toggleExpand(m); }
        }, null, null);
    }

    private void toggleExpand(Module m) {
        if (!expanded.remove(m)) expanded.add(m);
    }

    // ------------------------------------------------------------------ settings layout
    /** Lays out (and draws when {@code draw}) a module's settings. Returns the total height. */
    private int layoutSettings(DrawContext c, final Module m, int x, int y, int w, boolean draw) {
        int cy = y + 3;
        if (!m.alwaysOn) {
            cy += keyRow(c, x, cy, w, draw, "Keybind", m.keyCode(), bindModule == m,
                    new Runnable() {
                        @Override public void run() {
                            bindModule = m;
                            bindSetting = null;
                        }
                    },
                    new Runnable() {
                        @Override public void run() { m.setKeyCode(-1); }
                    });
        }
        for (Setting<?> s : m.settings()) {
            if (!s.visible()) continue;
            cy += settingRow(c, s, x, cy, w, draw);
        }
        cy += resetRow(c, m, x, cy, w, draw);
        return cy + 3 - y;
    }

    private int keyRow(DrawContext c, int x, int y, int w, boolean draw, String label, int key, boolean listening,
                       Runnable start, Runnable clear) {
        if (draw) {
            Draw.text(c, this.textRenderer, label, x + 1, y + 3, Theme.TEXT);
            int bw = 58;
            int bx = x + w - bw;
            boolean hov = hovered(bx, y, bw, 13);
            Draw.rrectBorder(c, bx, y, bw, 13, 2, listening ? Draw.mul(Theme.accent(), 0.5f) : (hov ? Theme.ROW_HOVER : Theme.ROW),
                    listening ? Theme.accent() : Theme.BORDER);
            String t = listening ? "press key..." : ModuleManager.keyName(key);
            Draw.textCentered(c, this.textRenderer, t, bx + bw / 2, y + 3, listening ? Theme.TEXT : Theme.MUTED);
            hit(bx, y, bw, 13, start, clear, null);
        }
        return 17;
    }

    private int resetRow(DrawContext c, final Module m, int x, int y, int w, boolean draw) {
        if (draw) {
            button(c, x, y + 2, w, 12, "Reset settings", true, Theme.BAD, new Runnable() {
                @Override public void run() { m.resetSettings(); }
            });
        }
        return 17;
    }

    private int settingRow(DrawContext c, final Setting<?> s, int x, int y, int w, boolean draw) {
        if (s instanceof Setting.Bool) {
            final Setting.Bool b = (Setting.Bool) s;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, b.label, w - 26), x + 1, y + 4, Theme.TEXT);
                toggleSwitch(c, x + w - 19, y + 3, b.on(), b);
                hit(x, y, w, 16, new Runnable() {
                    @Override public void run() {
                        b.toggle();
                        ConfigStore.markDirty();
                    }
                }, null, null);
            }
            return 17;
        }
        if (s instanceof Setting.Num) {
            final Setting.Num n = (Setting.Num) s;
            if (draw) {
                slider(c, x + 1, y, w - 2, n.label, n.display(), n.ratio(), new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        n.setRatio(r);
                        ConfigStore.markDirty();
                    }
                });
            }
            return 26;
        }
        if (s instanceof Setting.Mode) {
            final Setting.Mode md = (Setting.Mode) s;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, md.label, w / 2 - 2), x + 1, y + 4, Theme.TEXT);
                String v = "< " + md.get() + " >";
                Draw.textRight(c, this.textRenderer, Draw.fit(this.textRenderer, v, w / 2 + 6), x + w, y + 4, Theme.accent());
                hit(x, y, w, 16, new Runnable() {
                    @Override public void run() {
                        md.cycle(1);
                        ConfigStore.markDirty();
                    }
                }, new Runnable() {
                    @Override public void run() {
                        md.cycle(-1);
                        ConfigStore.markDirty();
                    }
                }, null);
            }
            return 17;
        }
        if (s instanceof Setting.Col) {
            final Setting.Col col = (Setting.Col) s;
            boolean open = openColors.contains(col);
            int h = 17;
            int pickerH = 0;
            if (open) pickerH = 12 * (col.allowAlpha ? 4 : 3) + 14 + 4;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, col.label, w - 30), x + 1, y + 4, Theme.TEXT);
                Draw.rrectBorder(c, x + w - 24, y + 3, 24, 10, 2, col.argb() | (col.allowAlpha ? 0 : 0xFF000000), open ? Theme.accent() : Theme.BORDER);
                hit(x, y, w, 16, new Runnable() {
                    @Override public void run() {
                        if (!openColors.remove(col)) openColors.add(col);
                    }
                }, null, null);
                if (open) {
                    colorPicker(c, x + 2, y + 18, w - 6, col, new java.util.function.IntSupplier() {
                        @Override public int getAsInt() { return col.argb(); }
                    }, new java.util.function.IntConsumer() {
                        @Override public void accept(int v) { col.set(v); }
                    }, col.allowAlpha);
                }
            }
            return h + pickerH;
        }
        if (s instanceof Setting.Text) {
            final Setting.Text t = (Setting.Text) s;
            if (draw) {
                Draw.text(c, this.textRenderer, t.label, x + 1, y + 2, Theme.TEXT);
                TextBox box = textBoxFor(t);
                textBox(c, x, y + 13, w, 14, box);
            }
            return 30;
        }
        if (s instanceof Setting.KeyBind) {
            final Setting.KeyBind kb = (Setting.KeyBind) s;
            return keyRow(c, x, y, w, draw, Draw.fit(this.textRenderer, kb.label, w - 62), kb.get(), bindSetting == kb,
                    new Runnable() {
                        @Override public void run() {
                            bindSetting = kb;
                            bindModule = null;
                        }
                    },
                    new Runnable() {
                        @Override public void run() {
                            kb.set(-1);
                            ConfigStore.markDirty();
                        }
                    });
        }
        if (s instanceof Setting.Blocks) {
            final Setting.Blocks bl = (Setting.Blocks) s;
            if (draw) {
                button(c, x, y + 1, w, 14, bl.label + " (" + bl.map().size() + ")", true, Theme.accent(), new Runnable() {
                    @Override public void run() { client.setScreen(new BlockPickerScreen(ClickGui.this, bl)); }
                });
            }
            return 18;
        }
        return 0;
    }

    private final java.util.Map<Setting.Text, TextBox> textBoxes = new java.util.HashMap<Setting.Text, TextBox>();

    private TextBox textBoxFor(Setting.Text t) {
        TextBox box = textBoxes.get(t);
        if (box == null) {
            box = new TextBox(t.maxLength);
            box.text = t.get();
            textBoxes.put(t, box);
        } else if (focused != box && !box.text.equals(t.get())) {
            box.text = t.get();
        }
        return box;
    }

    @Override
    protected void onTextChanged(TextBox box) {
        for (java.util.Map.Entry<Setting.Text, TextBox> e : textBoxes.entrySet()) {
            if (e.getValue() == box) {
                e.getKey().set(box.text);
                ConfigStore.markDirty();
            }
        }
    }

    private void renderTooltip(DrawContext c, Module m) {
        if (m.description == null || m.description.isEmpty()) return;
        List<String> lines = wrap(m.description, 200);
        int w = 0;
        for (String l : lines) w = Math.max(w, this.textRenderer.getWidth(l));
        int h = lines.size() * 10 + 8;
        int x = Math.min(this.width - w - 14, mouseX + 12);
        int y = Math.min(this.height - h - 34, mouseY + 12);
        Draw.rrectBorder(c, x, y, w + 10, h, 3, 0xF20B0713, Theme.accent());
        int ty = y + 4;
        for (String l : lines) {
            Draw.text(c, this.textRenderer, l, x + 5, ty, Theme.TEXT);
            ty += 10;
        }
    }

    private List<String> wrap(String text, int maxWidth) {
        List<String> out = new ArrayList<String>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String trial = line.length() == 0 ? word : line + " " + word;
            if (this.textRenderer.getWidth(trial) > maxWidth && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    // ------------------------------------------------------------------ HUD editor
    private final double[] hudGrab = new double[]{0, 0};

    private void renderHudView(DrawContext c) {
        List<HudModule> elements = new ArrayList<HudModule>();
        for (Module m : ModuleManager.all()) if (m instanceof HudModule) elements.add((HudModule) m);

        int lw = 170;
        int lh = 26 + elements.size() * 19 + 26;
        int lx = 10;
        int ly = 10;
        card(c, lx, ly, lw, lh);
        Draw.text(c, this.textRenderer, "HUD Elements", lx + 10, ly + 8, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "drag to move", lx + lw - 8, ly + 8, Theme.DIM);
        hit(lx, ly, lw, lh, null, null, null);
        int yy = ly + 24;
        for (final HudModule h : elements) {
            boolean hov = hovered(lx + 4, yy, lw - 8, 17);
            float on = anim(h.id + "#hudon", h.enabled() ? 1f : 0f);
            Draw.rrect(c, lx + 4, yy, lw - 8, 17, 3, Draw.lerp(hov ? Theme.ROW_HOVER : Theme.ROW, Draw.mul(Theme.accent(), 0.5f), on));
            Draw.text(c, this.textRenderer, h.name, lx + 10, yy + 5, Draw.lerp(Theme.MUTED, 0xFFFFFFFF, on));
            toggleSwitch(c, lx + lw - 28, yy + 4, h.enabled(), "hud" + h.id);
            hit(lx + 4, yy, lw - 8, 17, new Runnable() {
                @Override public void run() { h.toggle(); }
            }, null, null);
            yy += 19;
        }
        button(c, lx + 8, yy + 2, lw - 16, 16, "Reset positions", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                for (HudModule h : elements) {
                    h.settings().get(0).reset();
                    h.settings().get(1).reset();
                }
                ConfigStore.markDirty();
            }
        });

        for (final HudModule h : elements) {
            if (!h.enabled()) continue;
            h.draw(c, 0f, true);
            int bx = h.x();
            int by = h.y();
            int bw = Math.max(10, h.boxW);
            int bh = Math.max(10, h.boxH);
            boolean hov = Draw.inside(mouseX, mouseY, bx, by, bw, bh);
            int oc = hov ? Theme.accent() : Draw.alpha(Theme.accent(), 0.45f);
            c.fill(bx - 1, by - 1, bx + bw + 1, by, oc);
            c.fill(bx - 1, by + bh, bx + bw + 1, by + bh + 1, oc);
            c.fill(bx - 1, by, bx, by + bh, oc);
            c.fill(bx + bw, by, bx + bw + 1, by + bh, oc);
            final double[] grab = new double[]{Double.NaN, 0};
            hit(bx, by, bw, bh, new Runnable() {
                @Override public void run() { grab[0] = Double.NaN; }
            }, null, new Drag() {
                @Override public void to(double mxx, double myy) {
                    if (Double.isNaN(grab[0])) {
                        grab[0] = mxx - h.x();
                        grab[1] = myy - h.y();
                    }
                    int nx = (int) Math.round(mxx - grab[0]);
                    int ny = (int) Math.round(myy - grab[1]);
                    nx = Math.max(0, Math.min(width - Math.max(10, h.boxW), nx));
                    ny = Math.max(0, Math.min(height - Math.max(10, h.boxH), ny));
                    h.moveTo(nx, ny);
                    ConfigStore.markDirty();
                }
            });
        }
    }

    // ------------------------------------------------------------------ friends view
    private void renderFriendsView(DrawContext c) {
        int w = 320;
        int h = this.height - 80;
        int x = (this.width - w) / 2;
        int y = 28;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Friends", x + 12, y + 10, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "never targeted by combat modules", x + w - 12, y + 10, Theme.DIM);
        textBox(c, x + 12, y + 26, w - 90, 16, friendInput);
        button(c, x + w - 72, y + 26, 60, 16, "Add", true, Theme.accent(), new Runnable() {
            @Override public void run() { addFriendFromInput(); }
        });
        if (!friendStatus.isEmpty()) Draw.text(c, this.textRenderer, friendStatus, x + 12, y + 46, Theme.MUTED);

        int yy = y + 62;
        Draw.text(c, this.textRenderer, "Nearby players", x + 12, yy, Theme.MUTED);
        yy += 12;
        int shownNearby = 0;
        if (this.client != null && this.client.world != null) {
            for (final AbstractClientPlayerEntity p : this.client.world.getPlayers()) {
                if (p == this.client.player) continue;
                final String name = p.getName().getString();
                if (Friends.is(name)) continue;
                if (shownNearby >= 5) break;
                Draw.rrect(c, x + 12, yy, w - 24, 16, 3, Theme.ROW);
                Draw.text(c, this.textRenderer, name, x + 18, yy + 4, Theme.TEXT);
                button(c, x + w - 60, yy + 1, 42, 14, "+ Add", true, Theme.GOOD, new Runnable() {
                    @Override public void run() {
                        Friends.add(name);
                        friendStatus = "Added " + name;
                    }
                });
                yy += 18;
                shownNearby++;
            }
        }
        if (shownNearby == 0) {
            Draw.text(c, this.textRenderer, "No other players nearby", x + 18, yy + 2, Theme.DIM);
            yy += 14;
        }
        yy += 8;
        List<String> friends = Friends.list();
        Draw.text(c, this.textRenderer, "Friends (" + friends.size() + ")", x + 12, yy, Theme.MUTED);
        yy += 12;
        int rows = Math.max(1, (y + h - 10 - yy) / 18);
        friendScroll = Math.max(0, Math.min(Math.max(0, friends.size() - rows), friendScroll));
        if (pushClip(c, x + 8, yy, w - 16, rows * 18)) {
            for (int i = friendScroll; i < friends.size() && i < friendScroll + rows; i++) {
                final String name = friends.get(i);
                Draw.rrect(c, x + 12, yy, w - 24, 16, 3, Theme.ROW);
                Draw.text(c, this.textRenderer, name, x + 18, yy + 4, Theme.GOOD);
                button(c, x + w - 60, yy + 1, 42, 14, "Remove", true, Theme.BAD, new Runnable() {
                    @Override public void run() {
                        Friends.remove(name);
                        friendStatus = "Removed " + name;
                    }
                });
                yy += 18;
            }
            popClip(c);
        }
        if (friends.isEmpty()) Draw.text(c, this.textRenderer, "Your friends list is empty", x + 18, yy + 2, Theme.DIM);
    }

    private void addFriendFromInput() {
        String n = friendInput.text.trim();
        if (Friends.add(n)) {
            friendStatus = "Added " + n;
            friendInput.text = "";
        } else {
            friendStatus = "Enter a valid player name (letters, numbers, _)";
        }
    }

    // ------------------------------------------------------------------ theme view
    private void renderThemeView(DrawContext c) {
        int w = 320;
        int x = (this.width - w) / 2;
        int y = 28;
        int h = Math.min(this.height - 80, 330);
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Theme Editor", x + 12, y + 10, Theme.TEXT);
        int cy = y + 28;
        Draw.text(c, this.textRenderer, "Accent preset", x + 12, cy, Theme.MUTED);
        cy += 12;
        int sw = (w - 24 - 7 * 4) / 8;
        for (int i = 0; i < Theme.PRESETS.length; i++) {
            final int idx = i;
            int sx = x + 12 + i * (sw + 4);
            boolean sel = !Theme.useCustom && !Theme.rainbow && Theme.preset == i;
            Draw.rrectBorder(c, sx, cy, sw, 18, 3, Theme.PRESETS[i], sel ? 0xFFFFFFFF : Theme.BORDER);
            hit(sx, cy, sw, 18, new Runnable() {
                @Override public void run() {
                    Theme.preset = idx;
                    Theme.useCustom = false;
                    Theme.rainbow = false;
                    ConfigStore.markDirty();
                }
            }, null, null);
        }
        cy += 24;
        cy += toggleLine(c, x + 12, cy, w - 24, "Custom accent colour", Theme.useCustom, new Runnable() {
            @Override public void run() {
                Theme.useCustom = !Theme.useCustom;
                if (Theme.useCustom) Theme.rainbow = false;
                themePickerOpen = Theme.useCustom;
                ConfigStore.markDirty();
            }
        });
        if (Theme.useCustom) {
            cy += colorPicker(c, x + 14, cy, w - 28, "theme-custom", new java.util.function.IntSupplier() {
                @Override public int getAsInt() { return Theme.custom; }
            }, new java.util.function.IntConsumer() {
                @Override public void accept(int v) { Theme.custom = v | 0xFF000000; }
            }, false) + 4;
        }
        cy += toggleLine(c, x + 12, cy, w - 24, "Rainbow accent", Theme.rainbow, new Runnable() {
            @Override public void run() {
                Theme.rainbow = !Theme.rainbow;
                if (Theme.rainbow) Theme.useCustom = false;
                ConfigStore.markDirty();
            }
        });
        cy += 4;
        slider(c, x + 12, cy, w - 24, "Panel opacity", Math.round(Theme.panelOpacity * 100) + "%",
                (Theme.panelOpacity - 0.5) / 0.5, new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.panelOpacity = (float) (0.5 + r * 0.5);
                        ConfigStore.markDirty();
                    }
                });
        cy += 28;
        slider(c, x + 12, cy, w - 24, "Animation speed", String.format(Locale.ROOT, "%.1fx", Theme.animSpeed),
                (Theme.animSpeed - 0.4) / 2.1, new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.animSpeed = (float) (0.4 + r * 2.1);
                        ConfigStore.markDirty();
                    }
                });
        cy += 28;
        slider(c, x + 12, cy, w - 24, "Corner radius", String.valueOf(Theme.cornerRadius), Theme.cornerRadius / 5.0,
                new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.cornerRadius = (int) Math.round(r * 5.0);
                        ConfigStore.markDirty();
                    }
                });
        cy += 30;
        button(c, x + 12, cy, w - 24, 16, "Reset theme", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                Theme.reset();
                ConfigStore.markDirty();
            }
        });
    }

    private int toggleLine(DrawContext c, int x, int y, int w, String label, boolean on, Runnable click) {
        Draw.text(c, this.textRenderer, label, x, y + 4, Theme.TEXT);
        toggleSwitch(c, x + w - 20, y + 3, on, "tl" + label);
        hit(x, y, w, 16, click, null, null);
        return 19;
    }

    // ------------------------------------------------------------------ config view
    private void status(String text, boolean good) {
        cfgStatus = text;
        cfgGood = good;
        cfgStatusUntil = System.currentTimeMillis() + 5000L;
    }

    private void renderConfigView(DrawContext c) {
        int w = 440;
        int h = this.height - 80;
        int x = (this.width - w) / 2;
        int y = 28;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Config Manager", x + 12, y + 10, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "Active: " + ConfigStore.active(), x + w - 12, y + 10, Theme.accent());

        // profile list
        int lx = x + 12;
        int ly = y + 28;
        int lw = 200;
        int lh = h - 40;
        Draw.rrectBorder(c, lx, ly, lw, lh, 3, 0xFF0A0612, Theme.BORDER);
        List<String> profiles = ConfigStore.profiles();
        int rows = Math.max(1, (lh - 8) / 19);
        cfgScroll = Math.max(0, Math.min(Math.max(0, profiles.size() - rows), cfgScroll));
        if (pushClip(c, lx + 1, ly + 1, lw - 2, lh - 2)) {
            int yy = ly + 4;
            for (int i = cfgScroll; i < profiles.size() && i < cfgScroll + rows; i++) {
                final String name = profiles.get(i);
                boolean sel = name.equalsIgnoreCase(selectedProfile);
                boolean act = name.equalsIgnoreCase(ConfigStore.active());
                boolean hov = hovered(lx + 4, yy, lw - 8, 17);
                int bg = sel ? Draw.mul(Theme.accent(), 0.5f) : (hov ? Theme.ROW_HOVER : Theme.ROW);
                Draw.rrect(c, lx + 4, yy, lw - 8, 17, 3, bg);
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, name, lw - 70), lx + 10, yy + 5, sel ? 0xFFFFFFFF : Theme.TEXT);
                if (act) Draw.textRight(c, this.textRenderer, "active", lx + lw - 10, yy + 5, Theme.GOOD);
                hit(lx + 4, yy, lw - 8, 17, new Runnable() {
                    @Override public void run() {
                        selectedProfile = name;
                        configName.text = name;
                    }
                }, null, null);
                yy += 19;
            }
            popClip(c);
        }

        // actions
        int ax = lx + lw + 12;
        int aw = w - (ax - x) - 12;
        Draw.text(c, this.textRenderer, "Name", ax, ly + 1, Theme.MUTED);
        textBox(c, ax, ly + 12, aw, 16, configName);
        int by = ly + 36;
        final String sel = selectedProfile;
        button(c, ax, by, aw, 16, "Create new (from current)", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.create(configName.text)) {
                    selectedProfile = ConfigStore.active();
                    status("Created and activated \"" + ConfigStore.active() + "\"", true);
                } else {
                    status("Pick a unique name (letters, numbers, space, - _)", false);
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Save active", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                status(ConfigStore.saveActive() ? "Saved \"" + ConfigStore.active() + "\"" : "Save failed - see game log", ConfigStore.saveActive());
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Load selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.load(sel)) status("Loaded \"" + sel + "\"", true);
                else status("Select a profile to load", false);
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Rename selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.rename(sel, configName.text)) {
                    selectedProfile = ConfigStore.cleanName(configName.text);
                    status("Renamed to \"" + selectedProfile + "\"", true);
                } else {
                    status("Type a new unique name, then select a profile", false);
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Duplicate selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.duplicate(sel, configName.text)) status("Duplicated \"" + sel + "\"", true);
                else status("Type a new unique name for the copy", false);
            }
        });
        by += 20;
        boolean confirming = sel.equalsIgnoreCase(confirmDelete) && System.currentTimeMillis() < confirmUntil;
        button(c, ax, by, aw, 16, confirming ? "Click again to delete" : "Delete selected", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                if (sel.equalsIgnoreCase(confirmDelete) && System.currentTimeMillis() < confirmUntil) {
                    if (ConfigStore.delete(sel)) {
                        selectedProfile = ConfigStore.active();
                        status("Deleted \"" + sel + "\"", true);
                    } else {
                        status("Cannot delete the last remaining profile", false);
                    }
                    confirmDelete = "";
                } else {
                    confirmDelete = sel;
                    confirmUntil = System.currentTimeMillis() + 3000L;
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Reset active to defaults", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                ConfigStore.resetActiveToDefaults();
                status("Active profile reset to defaults", true);
            }
        });
        by += 24;
        if (System.currentTimeMillis() < cfgStatusUntil) {
            int yy = by;
            for (String line : wrap(cfgStatus, aw)) {
                Draw.text(c, this.textRenderer, line, ax, yy, cfgGood ? Theme.GOOD : Theme.BAD);
                yy += 10;
            }
        }
        Draw.text(c, this.textRenderer, "Profiles are saved to config/phantom/profiles", ax, ly + lh - 10, Theme.DIM);
    }

    // ------------------------------------------------------------------ input
    @Override
    protected boolean preClick(double mx, double my, int button) {
        if (bindModule != null || bindSetting != null) {
            int code = -100 - button;
            if (bindModule != null) bindModule.setKeyCode(code);
            if (bindSetting != null) {
                bindSetting.set(code);
                ConfigStore.markDirty();
            }
            bindModule = null;
            bindSetting = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (bindModule != null || bindSetting != null) {
            int code = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            if (bindModule != null) bindModule.setKeyCode(code);
            if (bindSetting != null) {
                bindSetting.set(code);
                ConfigStore.markDirty();
            }
            bindModule = null;
            bindSetting = null;
            return true;
        }
        if (focused == null && key == GLFW.GLFW_KEY_RIGHT_SHIFT && System.currentTimeMillis() - openedAt > 350L) {
            this.close();
            return true;
        }
        if (focused == friendInput && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            focused = null;
            addFriendFromInput();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int dir = vertical > 0 ? -1 : 1;
        if (view == View.MODULES) {
            for (int i = panels.size() - 1; i >= 0; i--) {
                Panel p = panels.get(i);
                if (p.cat != null && Draw.inside(mx, my, p.rx, p.ry, p.rw, p.rh)) {
                    p.scroll += dir * 22;
                    return true;
                }
            }
        } else if (view == View.FRIENDS) {
            friendScroll += dir;
            return true;
        } else if (view == View.CONFIG) {
            cfgScroll += dir;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }
}
