package dev.ratman.phantom.util;

import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Helpers for turning block identifiers into names and listing every registered block. */
public final class Blocks {
    private static List<String> cached;

    private Blocks() {}

    /** All block ids (path only for minecraft, full id for other namespaces), sorted. */
    public static List<String> allIds() {
        if (cached == null) {
            List<String> ids = new ArrayList<String>();
            for (Identifier id : Registries.BLOCK.getIds()) {
                ids.add(id.getNamespace().equals("minecraft") ? id.getPath() : id.toString());
            }
            Collections.sort(ids);
            cached = ids;
        }
        return cached;
    }

    public static Block block(String id) {
        Identifier identifier = id.contains(":") ? Identifier.of(id) : Identifier.ofVanilla(id);
        return Registries.BLOCK.get(identifier);
    }

    public static String displayName(String id) {
        try {
            return block(id).getName().getString();
        } catch (RuntimeException e) {
            return prettify(id);
        }
    }

    public static String prettify(String id) {
        String path = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(part.substring(0, 1).toUpperCase(Locale.ROOT)).append(part.substring(1));
        }
        return sb.toString();
    }

    public static boolean isStorageId(String id) {
        return id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel") || id.equals("ender_chest")
                || id.contains("shulker_box") || id.equals("hopper") || id.equals("dispenser") || id.equals("dropper")
                || id.equals("furnace") || id.equals("blast_furnace") || id.equals("smoker")
                || id.equals("brewing_stand") || id.equals("chiseled_bookshelf") || id.equals("crafter")
                || id.equals("decorated_pot");
    }

    public static List<String> storageIds() {
        List<String> out = new ArrayList<String>();
        for (String id : allIds()) if (isStorageId(id)) out.add(id);
        return out;
    }
}
