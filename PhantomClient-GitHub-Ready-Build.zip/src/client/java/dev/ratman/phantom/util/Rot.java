package dev.ratman.phantom.util;

import net.minecraft.util.math.Vec3d;

/** Rotation maths. Yaw/pitch follow Minecraft conventions (yaw 0 = +Z, pitch -90 = up). */
public final class Rot {
    private Rot() {}

    public static float wrap(float degrees) {
        float d = degrees % 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /** Returns {yaw, pitch} needed to look from {@code from} toward {@code to}. */
    public static float[] anglesTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return new float[]{wrap(yaw), Math.max(-90f, Math.min(90f, pitch))};
    }

    /** Angular distance (degrees) between the current view and a target direction. */
    public static double angleBetween(float yaw, float pitch, float targetYaw, float targetPitch) {
        float dy = wrap(targetYaw - yaw);
        float dp = targetPitch - pitch;
        return Math.sqrt(dy * dy + dp * dp);
    }
}
