package dev.ratman.phantom.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ConnectScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Every call that is likely to change between Minecraft releases lives here so that, if a future
 * mapping update breaks compilation, there is exactly one file to adjust.
 */
public final class Compat {
    private Compat() {}

    /** Entity position built from getX/getY/getZ (the Entity#getPos accessor was renamed in newer mappings). */
    public static net.minecraft.util.math.Vec3d pos(net.minecraft.entity.Entity e) {
        return new net.minecraft.util.math.Vec3d(e.getX(), e.getY(), e.getZ());
    }

    public static float tickDelta() {
        return MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
    }

    public static void playSound(String vanillaId, float volume, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        SoundEvent event = SoundEvent.of(Identifier.ofVanilla(vanillaId));
        mc.getSoundManager().play(PositionedSoundInstance.master(event, pitch, volume));
    }

    public static void disconnect(String reason) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler != null) handler.getConnection().disconnect(Text.literal(reason));
    }

    public static void reconnect(ServerInfo info) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ConnectScreen.connect(new MultiplayerScreen(new TitleScreen()), mc,
                ServerAddress.parse(info.address), info, false, null);
    }

    public static void selectHotbar(int slot) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && slot >= 0 && slot < 9) mc.player.getInventory().setSelectedSlot(slot);
    }

    public static int selectedHotbar() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null ? 0 : mc.player.getInventory().getSelectedSlot();
    }

    public static void clipboard(String text) {
        MinecraftClient.getInstance().keyboard.setClipboard(text);
    }
}
