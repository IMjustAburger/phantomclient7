package dev.ratman.phantom.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Small 2D drawing helpers shared by the ClickGUI and HUD. */
public final class Draw {
    private Draw() {}

    public static int alpha(int color, float a) {
        int base = (color >>> 24) & 0xFF;
        int na = Math.max(0, Math.min(255, Math.round(base * a)));
        return (color & 0xFFFFFF) | (na << 24);
    }

    public static int setAlpha(int color, int a) {
        return (color & 0xFFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    public static int mul(int color, float f) {
        int a = (color >>> 24) & 0xFF;
        int r = Math.min(255, Math.round(((color >> 16) & 0xFF) * f));
        int g = Math.min(255, Math.round(((color >> 8) & 0xFF) * f));
        int b = Math.min(255, Math.round((color & 0xFF) * f));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    public static float approach(float current, float target, float speed) {
        float d = target - current;
        if (Math.abs(d) < 0.001f) return target;
        return current + d * Math.min(1f, speed);
    }

    public static int hsb(float h, float s, float b) {
        h = h - (float) Math.floor(h);
        float r = 0, g = 0, bl = 0;
        float hh = (h * 6f);
        int sector = (int) Math.floor(hh);
        float f = hh - sector;
        float p = b * (1f - s);
        float q = b * (1f - s * f);
        float t = b * (1f - s * (1f - f));
        switch (sector) {
            case 0: r = b; g = t; bl = p; break;
            case 1: r = q; g = b; bl = p; break;
            case 2: r = p; g = b; bl = t; break;
            case 3: r = p; g = q; bl = b; break;
            case 4: r = t; g = p; bl = b; break;
            default: r = b; g = p; bl = q; break;
        }
        return 0xFF000000 | (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(bl * 255);
    }

    /** Returns {hue, saturation, brightness} in 0..1. */
    public static float[] toHsb(int color) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h;
        if (d == 0) h = 0;
        else if (max == r) h = ((g - b) / d) % 6f;
        else if (max == g) h = (b - r) / d + 2f;
        else h = (r - g) / d + 4f;
        h = h / 6f;
        if (h < 0) h += 1f;
        float s = max == 0 ? 0 : d / max;
        return new float[]{h, s, max};
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Filled rectangle with softly rounded corners (radius up to ~5px). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        if (r <= 0 || w < 2 * r + 1 || h < 2 * r + 1) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    /** Rounded rect with a 1px border drawn as two stacked rrects. */
    public static void rrectBorder(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x, y, w, h, r, border);
        rrect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static void text(DrawContext c, TextRenderer font, String s, int x, int y, int color) {
        c.drawText(font, s, x, y, color, true);
    }

    public static void textRight(DrawContext c, TextRenderer font, String s, int right, int y, int color) {
        c.drawText(font, s, right - font.getWidth(s), y, color, true);
    }

    public static void textCentered(DrawContext c, TextRenderer font, String s, int cx, int y, int color) {
        c.drawText(font, s, cx - font.getWidth(s) / 2, y, color, true);
    }

    /** Draws a string clipped with an ellipsis so it fits {@code maxWidth}. */
    public static String fit(TextRenderer font, String s, int maxWidth) {
        if (font.getWidth(s) <= maxWidth) return s;
        String ell = "..";
        int n = s.length();
        while (n > 0 && font.getWidth(s.substring(0, n) + ell) > maxWidth) n--;
        return s.substring(0, Math.max(0, n)) + ell;
    }

    /** Small chevron drawn from 1px fills (no special font glyphs needed). down=true points down. */
    public static void chevron(DrawContext c, int x, int y, int color, boolean down) {
        for (int i = 0; i < 4; i++) {
            int row = down ? i : 3 - i;
            c.fill(x + i, y + row, x + i + 1, y + row + 1, color);
            c.fill(x + 7 - i, y + row, x + 8 - i, y + row + 1, color);
        }
    }

    /** Right-pointing chevron. */
    public static void chevronRight(DrawContext c, int x, int y, int color) {
        for (int i = 0; i < 4; i++) {
            int col = i;
            c.fill(x + col, y + i, x + col + 1, y + i + 1, color);
            c.fill(x + col, y + 7 - i, x + col + 1, y + 8 - i, color);
        }
    }
}
