package dev.ratman.phantom.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Shared target filtering used by every combat / ESP module. */
public final class Targets {
    public static final String[] KINDS = {"Players", "Mobs", "Both"};
    private static final Map<Integer, Vec3d> LAST_POS = new HashMap<Integer, Vec3d>();
    private static final Map<Integer, Vec3d> VELOCITY = new HashMap<Integer, Vec3d>();

    private Targets() {}

    public static boolean isFriend(Entity e) {
        return e instanceof PlayerEntity && Friends.is(e.getName().getString());
    }

    /**
     * @param kind           "Players", "Mobs" or "Both"
     * @param includePassive whether non-hostile mobs count as "Mobs"
     */
    public static boolean valid(LivingEntity e, String kind, boolean includePassive) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e == null || mc.player == null || e == mc.player) return false;
        if (!e.isAlive() || e.isSpectator()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) {
            if (kind.equals("Mobs")) return false;
            if (Friends.is(e.getName().getString())) return false;
            return !((PlayerEntity) e).isCreative();
        }
        if (kind.equals("Players")) return false;
        if (e instanceof TameableEntity && ((TameableEntity) e).isTamed()) return false;
        return includePassive || e instanceof Monster;
    }

    public static List<LivingEntity> nearby(double range, String kind, boolean includePassive) {
        List<LivingEntity> out = new ArrayList<LivingEntity>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return out;
        double r2 = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity)) continue;
            LivingEntity le = (LivingEntity) e;
            if (mc.player.squaredDistanceTo(le) > r2) continue;
            if (valid(le, kind, includePassive)) out.add(le);
        }
        return out;
    }

    /** Called once per client tick so remote entities get a measured velocity (the server value is often zero). */
    public static void trackMotion() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) {
            LAST_POS.clear();
            VELOCITY.clear();
            return;
        }
        Map<Integer, Vec3d> next = new HashMap<Integer, Vec3d>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity)) continue;
            Vec3d now = Compat.pos(e);
            Vec3d before = LAST_POS.get(e.getId());
            if (before != null) VELOCITY.put(e.getId(), now.subtract(before));
            next.put(e.getId(), now);
        }
        LAST_POS.clear();
        LAST_POS.putAll(next);
        VELOCITY.keySet().retainAll(next.keySet());
    }

    public static Vec3d velocity(Entity e) {
        Vec3d v = VELOCITY.get(e.getId());
        return v == null ? Vec3d.ZERO : v;
    }
}
